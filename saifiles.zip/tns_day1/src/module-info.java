/**
 * 
 */
/**
 * 
 */
module tns_day1 {
}
package approaches;

public class Variables1 {
int b=20;
static String c="santhosh";
}

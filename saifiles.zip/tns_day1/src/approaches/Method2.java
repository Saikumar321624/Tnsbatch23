package approaches;

public class Method2 {
	 static int a=20;
	  String b="saikumar";
	  public int display() {
		  return 60;
	  }
	  static void display1() {
		  System.out.println("tns class");
	  }
}

package approaches;

public class B {
	 public static void main(String[] args) {
		 Method2 d =new Method2();
		  System.out.println(d.b);
		  System.out.println(d.display());
		  System.out.println(Methods1.a);
		  Methods1.display1();
	}
	
}

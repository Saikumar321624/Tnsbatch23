package approaches;

public class Variables {
 int a= 20;
 static String b="saikumar";
public static void main(String[] args) {
	int c=30;
	System.out.println(c);
	Variables s= new Variables();
	System.out.println(s.a);
	System.out.println(b);
	
}
}
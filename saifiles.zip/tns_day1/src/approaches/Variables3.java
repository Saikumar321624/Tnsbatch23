package approaches;

public class Variables3 {
	public static void main(String[] args) {

int e=40;
System.out.println(e);
Variables1 d=new Variables1();
System.out.println(d.b);
System.out.println(Variables1.c);
}
}
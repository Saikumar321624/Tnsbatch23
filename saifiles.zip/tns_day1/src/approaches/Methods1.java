package approaches;

public class Methods1 {
 static int a=20;
  String b="saikumar";
  public int display() {
	  return 60;
  }
  static void display1() {
	  System.out.println("tns class");
  }
  public static void main(String[] args) {
	  Methods1 d=new Methods1();
	  System.out.println(d.b);
	  System.out.println(d.display());
	  System.out.println(Methods1.a);
	  Methods1.display1();
}
}

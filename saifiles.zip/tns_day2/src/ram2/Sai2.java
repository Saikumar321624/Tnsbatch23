package ram2;
import ram.Sai;
class Sai2 extends Sai{
public static void main(String[] args) {
	Sai2 a= new Sai2();
	a.display();
}
}

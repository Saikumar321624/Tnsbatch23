package privat;

public class A {
	private void display() {
		System.out.println("tns calss");
	}
public static void main(String[] args) {
	A a1= new A();
	a1.display();
}
}

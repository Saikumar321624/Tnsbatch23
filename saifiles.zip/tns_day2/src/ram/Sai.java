package ram;

public class Sai {
protected void display() {
	System.out.println("hey  hello");
}
}

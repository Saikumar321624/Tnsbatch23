package gettersetter;

public class Mainstudentfunctionality {
	public static void main(String[] args) {
		

	Studentfunctionality student=new Studentfunctionality();
	student.setName("saikumar");
	System.out.println(student.getName());
	student.setCollage("sri indhu collage");
	System.out.println(student.getCollage());
	student.setAge(20);
	System.out.println(student.getAge());
	System.out.println(student.run());
	}
}


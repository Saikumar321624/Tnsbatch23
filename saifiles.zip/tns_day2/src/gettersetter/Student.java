package gettersetter;

public class Student {
	
		
		private String Name;
		private String collage;
		public int Age ;


}

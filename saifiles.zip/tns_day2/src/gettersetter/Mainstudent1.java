package gettersetter;

public class Mainstudent1 {
public static void main(String[] args) {
	Student1 a=new Student1();
	a.setName("saikumar");
	System.out.println(a.getName());
	
	a.setCollage("sri indhu collage");
	System.out.println(a.getCollage());
	 
	a.Age=20;
	System.out.println(a.Age);

}
}

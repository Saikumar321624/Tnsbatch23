package gettersetter;

public class Studentfunctionality {
	private String Name;
	private String collage;
	private int Age ;

	public String getName() {
		return Name;
	}
	public void setName(String name) {
		this.Name = name;
	}
	public String getCollage() {
		return collage;
	}
	public void setCollage(String collage) {
		this.collage = collage;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		this.Age = age;
	}
	public String run() {
		if (Age>18 &&  collage.equals("sri indhu collage") && Name.equals("saikumar")) {
			return "he can enter into the collage";
		}else {
			return"he cannot enter the collage";
		}
	}
	}
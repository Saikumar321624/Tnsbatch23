package gettersetter;


public class Mainstudent {
	public static void main(String[] args) {
		Student s= new Student();
		s.Age=30;
	System.out.println(s.Age);
	}}
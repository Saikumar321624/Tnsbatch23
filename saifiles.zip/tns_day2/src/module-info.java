/**
 * 
 */
/**
 * 
 */
module tns_day2 {
}
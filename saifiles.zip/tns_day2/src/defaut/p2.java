package defaut;

public class p2 {
public static void main(String[] args) {
	p1 p=new p1();
	p.display();
}
}

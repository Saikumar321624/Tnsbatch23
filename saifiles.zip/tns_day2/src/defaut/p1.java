package defaut;

public class p1 {
void display() {
	System.out.println("tns class");
}
}

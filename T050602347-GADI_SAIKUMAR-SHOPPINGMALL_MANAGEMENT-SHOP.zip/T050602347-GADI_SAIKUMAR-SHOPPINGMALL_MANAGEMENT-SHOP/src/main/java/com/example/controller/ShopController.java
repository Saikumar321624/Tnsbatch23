package com.example.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;

import com.example.entity.Shop;
import com.example.exception.ResourceNotFoundException;
import com.example.repository.ShopRepository;

@RestController
@RequestMapping("/api/v1/shops")
public class ShopController {
@Autowired
private ShopRepository repo;
@GetMapping("/shops")
public List<Shop> getAllEmployees(){
	return repo.findAll();
}
@PostMapping("/shops")
public Shop createEmployee(@RequestBody Shop shop) {
	return repo.save(shop);
}
@GetMapping("/shops/{id}")
public ResponseEntity<Shop> getEmployeeById(@PathVariable Long id) {
	Shop shop = repo.findById(id)
			.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
	return ResponseEntity.ok(shop);
}
@PutMapping("/shops/{id}")
public ResponseEntity<Shop> updateEmployee(@PathVariable Long id, @RequestBody Shop shopDetails){
	Shop shop = repo.findById(id)
			.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
	
	shop.setName(shopDetails.getName());
	
	
	Shop updatedShop = repo.save(shop);
	return ResponseEntity.ok(updatedShop);
}
@DeleteMapping("/shops/{id}")
public ResponseEntity<Map<String, Boolean>> deleteEmployee(@PathVariable Long id){
	Shop shop = repo.findById(id)
			.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
	
	repo.delete(shop);
	Map<String, Boolean> response = new HashMap<>();
	response.put("deleted", Boolean.TRUE);
	return ResponseEntity.ok(response);
}
}
